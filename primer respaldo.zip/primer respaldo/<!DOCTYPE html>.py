<!DOCTYPE html>

<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Agenda 23-05-23</title>
    </head>
    <body>
        <h1>
            Sesión 01
        </h1>
        <h2>
            Fecha de la sesión: 23-05-2023            
            <br>
            Lugar: Sela de sesiones de computación
            <hr>
        </h2>
        <h2>Participantes</h2>
        <ul>
            <li>Leonardo Víquez Acuña</li>
            <li>María Ríos Espinoza</li>
        </ul>
        <h2>Agenda</h2>
        <ul type="I">
            <li>Apertura de la sesión
                <ol type="1">
                    <li style="color: rgb(25, 0, 247);">Bienvenida a los miembros del consejo
                        <ul type="disc">
                            <h3>[Transcripción de la discusión]</h3>
                            <strong>Leonardo Víquez Acuña:</strong>
                            <p style="font-style: italic;">
                                Bienvenidos a la sesión de hoy del Consejo Académico de Computación. Comencemos con la revisión de la agenda. ¿Estamos todos aquí? Veo que tenemos a los miembros habituales y algunos invitados. Gracias por unirse a nosotros. ¿Hay alguna introducción o anuncio antes de pasar al primer punto de la agenda?
                            </p>
                            <br>
                            <strong>María Ríos Espinoza:</strong>
                            <p style="font-style: italic;">
                                Buenas tardes a todos?
                            </p>
                            
                        </ul>
                    </li>
                    <li style="font-size: 24px; border-width: 3px; border-radius: 5px; border-style: dotted; border-color: blueviolet;">
                        Introducción del moderador de la sesión
                    </li>
                </ol>
            </li>
            <li>Lectura y aprobación del acta de la sesión anterior
                <ol start=3 type="1">
                    <li style="border-bottom: 2px solid chocolate ;">Revisión del acta de la sesión anterior</li>
                    <li>Discusión sobre los puntos planteados en el acta</li>
                    <li>Votación para aprobar el acta</li>
                </ol>
            </li>
            <li>Informe del Director del Departamento
                <ol start="6" type="1">
                    <li>Actualización sobre los logros y desafíos del departamento</li>
                    <li>Proyectos y actividades destacadas</li>
                    <li>Oportunidades de colaboración y crecimiento</li>
                </ol>
            </li>
        </ul>
    </body>
</html>