import webview
import agenda as a

pass


def generar_html(lista_elementos):
    # Crea la estructura básica del HTML
    html = """<html><head>
                <meta charset="UTF-8 \">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Agenda 23-05-23</title>
                </head><body>"""
    
    html=html+'<ol>'
    # Genera el contenido basado en la lista de elementos
    for elemento in lista_elementos:
        html += f"<li>{elemento}</li>"
    
    # Cierra las etiquetas del HTML
    html=html+'</ol>'
    html += "</body></html>"
    
    # Devuelve el código HTML generado
    return html

def mostrar_html_en_ventana(codigo_html):
    # Crea una ventana y carga el contenido HTML
    webview.create_window("Visor HTML", html=codigo_html)

    # Inicia el bucle de la aplicación
    webview.start()

# Ejemplo de lista de elementos
lista = ["Elemento 1 ", "Elemento 2", "Elemento 3"]

# Genera el código HTML utilizando la función anterior
codigo_html_generado = generar_html(lista)

# Genera el código HTML utilizando la función anterior
file= open("sesion.html", 'tr') #cambie 'tr' por 'w'  alguno de los dos si es de lectura (MAR)

sesion01_html = file.read()

# Muestra el código HTML en una ventana
mostrar_html_en_ventana(codigo_html_generado)
mostrar_html_en_ventana(sesion01_html)


class Participante:
    def __init__(self, nombre, apellido1, apellido2):
        self.nombre = nombre
        self.apellido1 = apellido1
        self.apellido2 = apellido2

class Discusion:
    def __init__(self, persona, discusion):
        self.persona = persona
        self.discusion = discusion
        self.sig = None

class Punto:
    def __init__(self, punto):
        self.punto = punto
        self.discusiones = None
        self.sig = None

class Apartado:
    def __init__(self, apartado):
        self.apartado = apartado
        self.puntos = None
        self.sig = None

class Agenda:
    def __init__(self):
        self.participantes = None
        self.apartados = None

    def agregar_participante(self, nombre, apellido1, apellido2):
        participante = Participante(nombre, apellido1, apellido2)
        if self.participantes is None:
            self.participantes = participante
        else:
            current = self.participantes
            while current.sig:
                current = current.sig
            current.sig = participante

    def agregar_apartado(self, apartado):
        nuevo_apartado = Apartado(apartado)
        if self.apartados is None:
            self.apartados = nuevo_apartado
        else:
            current = self.apartados
            while current.sig:
                current = current.sig
            current.sig = nuevo_apartado

    def agregar_punto(self, apartado, punto):
        current = self.apartados
        while current:
            if current.apartado == apartado:
                nuevo_punto = Punto(punto)
                if current.puntos is None:
                    current.puntos = nuevo_punto
                else:
                    punto_actual = current.puntos
                    while punto_actual.sig:
                        punto_actual = punto_actual.sig
                    punto_actual.sig = nuevo_punto
                break
            current = current.sig

    def agregar_discusion(self, apartado, punto, persona, discusion):
        current = self.apartados
        while current:
            if current.apartado == apartado:
                punto_actual = current.puntos
                while punto_actual:
                    if punto_actual.punto == punto:
                        nueva_discusion = Discusion(persona, discusion)
                        if punto_actual.discusiones is None:
                            punto_actual.discusiones = nueva_discusion
                        else:
                            discusion_actual = punto_actual.discusiones
                            while discusion_actual.sig:
                                discusion_actual = discusion_actual.sig
                            discusion_actual.sig = nueva_discusion
                        break
                    punto_actual = punto_actual.sig
                break
            current = current.sig

import agenda as a

# Ejemplo de uso:
agenda1 = a.Agenda()

# Registro de participantes en la agenda
agenda1.agregar_participante('Persona1', 'Sin', 'Apellidos')
agenda1.agregar_participante('Persona2', 'Sin', 'Apellidos')
agenda1.agregar_participante('Persona3', 'Sin', 'Apellidos')

# Registro de apartados
agenda1.agregar_apartado('Apartado1')
agenda1.agregar_apartado('Apartado2')
agenda1.agregar_apartado('Apartado3')

# Registro de puntos
agenda1.agregar_punto('Apartado1', 'Punto1')
agenda1.agregar_punto('Apartado1', 'Punto2')
agenda1.agregar_punto('Apartado2', 'Punto3')
agenda1.agregar_punto('Apartado2', 'Punto4')
agenda1.agregar_punto('Apartado2', 'Punto5')

# Registro de discusiones
agenda1.agregar_discusion('Apartado1', 'Punto1', agenda1.participantes, 'discusión1')
agenda1.agregar_discusion('Apartado1', 'Punto1', agenda1.participantes.sig, 'discusión2')
agenda1.agregar_discusion('Apartado1', 'Punto2', agenda1.participantes, 'discusión1')
agenda1.agregar_discusion('Apartado1', 'Punto2', agenda1.participantes.sig, 'discusión2')
agenda1.agregar_discusion('Apartado1', 'Punto2', agenda1.participantes, 'discusión3')
agenda1.agregar_discusion('Apartado2', 'Punto3', agenda1.participantes, 'discusión1')
agenda1.agregar_discusion('Apartado2', 'Punto3', agenda1.participantes.sig.sig, 'discusión2')
agenda1.agregar_discusion('Apartado2', 'Punto4', agenda1.participantes.sig, 'discusión3')
agenda1.agregar_discusion('Apartado2', 'Punto5', agenda1.participantes, 'discusión2')
agenda1.agregar_discusion('Apartado2', 'Punto5', agenda1.participantes.sig.sig, 'discusión2')
